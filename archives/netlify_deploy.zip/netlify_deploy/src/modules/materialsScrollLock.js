// Placeholder stub for materialsScrollLock
export function initMaterialsScrollLock () {
  // no‑op
}
