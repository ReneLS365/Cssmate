// Placeholder for materialRowTemplate
export function createMaterialRow () {
  // Return a simple div that indicates missing template
  const div = document.createElement('div');
  div.textContent = 'Material row template placeholder';
  return div;
}
