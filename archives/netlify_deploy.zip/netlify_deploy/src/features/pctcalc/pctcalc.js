// Placeholder stub for pctcalc module
// Export a default function that does nothing
export default function () {}
