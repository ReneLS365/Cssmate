// Placeholder stub for numpad.lazy.js
export function installLazyNumpad () {
  // No‑op: this stub intentionally does nothing.
}
