// Placeholder for ClickGuard
export function initClickGuard () {
  // no‑op
}
