export const SW_VERSION = "v5-hulmose-alfix-ready";
