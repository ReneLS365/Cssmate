import { openNumpad } from './numpad.js'
import { devlog } from '../utils/devlog.js'

let autoFieldId = 0

function parseNumericValue (value) {
  if (typeof value !== 'string') return 0
  const normalized = value.replace(/,/g, '.').trim()
  if (normalized === '') return 0
  const parsed = Number.parseFloat(normalized)
  return Number.isFinite(parsed) ? parsed : 0
}

function ensureFieldIdentifier (input) {
  if (!(input instanceof HTMLInputElement)) return
  if (input.hasAttribute('data-numpad-field')) return
  const explicit = input.getAttribute('id') || input.getAttribute('name') || input.dataset.id || ''
  autoFieldId += 1
  const value = explicit && explicit.trim() ? explicit.trim() : `np-field-${autoFieldId}`
  input.setAttribute('data-numpad-field', value)
}

function formatResult (value, useComma) {
  const numeric = Number(value)
  const stringValue = Number.isFinite(numeric) ? String(numeric) : '0'
  return useComma ? stringValue.replace('.', ',') : stringValue
}

function applyBinding (input) {
  if (!(input instanceof HTMLInputElement)) return
  if (input.dataset.npBound === 'true') return
  if (input.disabled) return

  input.dataset.npBound = 'true'
  ensureFieldIdentifier(input)
  const originalInputMode = input.getAttribute('inputmode')
  if (!originalInputMode || originalInputMode === 'numeric') {
    input.setAttribute('inputmode', 'decimal')
  }
  input.readOnly = true

  const isClosingGuardActive = () => {
    if (typeof document === 'undefined') return false
    const body = document.body
    if (!body) return false
    try {
      return body.dataset?.numpadClosing === '1'
    } catch {
      return body.getAttribute('data-numpad-closing') === '1'
    }
  }

  const open = async () => {
    if (isClosingGuardActive()) return
    const currentValue = input.value
    const baseValue = parseNumericValue(currentValue)
    devlog.mark('numpad:trigger')
    devlog.time('numpad:trigger→open')
    const value = await openNumpad({ startValue: currentValue, baseValue })
    if (value == null) return
    const useComma = input.dataset.decimal === 'comma'
    input.value = formatResult(value, useComma)
    input.dispatchEvent(new Event('input', { bubbles: true }))
    input.dispatchEvent(new Event('change', { bubbles: true }))
  }

  input.addEventListener('click', event => {
    if (isClosingGuardActive()) {
      event.preventDefault()
      event.stopPropagation()
      return
    }
    void open()
  })
  input.addEventListener('keydown', event => {
    if (isClosingGuardActive()) {
      event.preventDefault()
      event.stopPropagation()
      return
    }
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      void open()
    }
  })
}

function scan (root) {
  root.querySelectorAll('input[data-numpad="true"]').forEach(applyBinding)
}

export function initNumpadBinding (root = document) {
  const target = root === document ? document.body : root
  if (!target) return

  scan(target)

  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(node => {
          if (!(node instanceof Element)) return
          if (node.matches('input[data-numpad="true"]')) {
            applyBinding(node)
          }
          node.querySelectorAll?.('input[data-numpad="true"]').forEach(applyBinding)
        })
      }
      if (mutation.type === 'attributes' && mutation.attributeName === 'data-numpad') {
        const targetNode = mutation.target
        if (targetNode instanceof HTMLInputElement && targetNode.dataset.numpad === 'true') {
          applyBinding(targetNode)
        }
      }
    })
  })

  observer.observe(target, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-numpad'] })
  return () => observer.disconnect()
}
