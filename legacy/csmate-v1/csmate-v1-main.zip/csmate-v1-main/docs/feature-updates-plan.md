# Feature Updates Discovery Plan

## Repository Setup
- Checked out new branch `feature-updates` from existing base (`work` branch).
- Static site structure stored under `/app` with HTML/CSS/JS entrypoints.
- Local preview works via `python -m http.server 8000` (opens `http://localhost:8000/app/index.html`).

## Key Entry Points
- `app/index.html`: main markup, header navigation (`Optælling`, `Løn`, `Guide`) with sections and modals.
- `app/style.css`: global styles including grid helpers (`grid-3`, `.row`), buttons, responsive adjustments.
- `app/print.css`: print-specific overrides for export.
- `app/main.js`: client-side logic for tabs, materials dataset, CSV handling, totals, export helpers, and payroll calculations.
- `app/dataset.js`: supplemental data definitions (not yet imported by default but available).

## Implementation Outline
1. Replace Guide tab with new `Sagsinfo` section and relocate/extend case metadata fields.
2. Implement validation that gates export/print actions until Sagsinfo is complete.
3. Update CSS for responsive/mobile experience (grid collapse, spacing, touch target sizing).
4. Extend numeric keypad script in `app/main.js` to attach globally to numeric inputs.
5. Replace CSV upload button with drag-and-drop import surface; wire into existing parsing/export logic.
6. Ensure material list renders three manual rows that affect totals and exports.
7. Introduce Materialesum, Lønsum, Projektsum totals in UI and exports/print outputs.
8. Document and test changes in `/docs/feature-updates-testing.md`, update README with new workflows.
