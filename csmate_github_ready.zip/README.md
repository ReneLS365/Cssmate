# CSMate – simple/mobile deploy snapshot

Denne mappe indeholder `app/`-mappen klar til at blive lagt direkte ind i dit `csmate-v1` GitHub-repo.

Kopier hele `app/`-mappen ind i roden af repoet (eller på en ny branch), commit, og deploy via Netlify.
