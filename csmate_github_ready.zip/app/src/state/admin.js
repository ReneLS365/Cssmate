// Placeholder for admin state management
export function setAdminOk () {
  // no‑op
}
export function setLock () {
  // no‑op
}
