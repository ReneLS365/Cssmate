// Placeholder for virtual materials list implementation
export function createVirtualMaterialsList () {
  return {
    destroy () {},
    refresh () {}
  };
}
